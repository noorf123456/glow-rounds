/* Glow Rounds offline cache. Photos and check-ins are never sent anywhere; this only stores the app's own files. */
const CACHE = 'glow-rounds-8740208b62';
const FILES = ["./", "./index.html", "./face-api.js", "./manifest.webmanifest", "./icon-180.png", "./icon-192.png", "./icon-512.png", "./icon-maskable-512.png", "./bodoni-moda-latin-500-italic.woff2", "./bodoni-moda-latin-500-normal.woff2", "./figtree-latin-400-normal.woff2", "./figtree-latin-500-normal.woff2", "./figtree-latin-600-normal.woff2", "./figtree-latin-700-normal.woff2", "./ibm-plex-mono-latin-400-normal.woff2", "./ibm-plex-mono-latin-500-normal.woff2"];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then((r) => {
      const copy = r.clone();
      caches.open(CACHE).then((c) => c.put('./index.html', copy));
      return r;
    }).catch(() => caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request)));
});
